package libreria;

public class Bibliotecario extends Persona  {
	
	private int idBibliotecario ;
	private int codSucursal;
	
	
	public Bibliotecario(String nombre, String apellido, int idBibliotecario, int codSucursal) {
		super(nombre, apellido);
		this.idBibliotecario = idBibliotecario;
		this.codSucursal=codSucursal;
	}
	
	public Bibliotecario() {
		
	}
	
	public void recomendarLibro(Cliente cliente, Libro libro) {
		
	}
	public void hacerVenta (Cliente cliente, Libro libro) {
		
	}


	public int getIdBibliotecario() {
		return idBibliotecario;
	}

	public void setIdBibliotecario(int idBibliotecario) {
		this.idBibliotecario = idBibliotecario;
	}
	
	public int getCodSucursal() {
		return codSucursal;
	}

	public void setCodSucursal(int codSucursal) {
		this.codSucursal = codSucursal;
	}

	

}
