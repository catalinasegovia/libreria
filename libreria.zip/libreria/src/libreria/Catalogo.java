package libreria;

import java.util.LinkedList;

public class Catalogo {
	private int idCatalogo;
	private LinkedList <Libro> librosCatalogo;
	
	public Catalogo(int idCatalogo, LinkedList<Libro> librosCatalogo) {
		super();
		this.idCatalogo = idCatalogo;
		this.librosCatalogo = librosCatalogo;
	}
	
	public Catalogo() {
		
	}
	public int getIdCatalogo() {
		return idCatalogo;
	}



	public void setIdCatalogo(int idCatalogo) {
		this.idCatalogo = idCatalogo;
	}



	public LinkedList<Libro> getLibrosCatalogo() {
		return librosCatalogo;
	}



	public void setLibrosCatalogo(LinkedList<Libro> librosCatalogo) {
		this.librosCatalogo = librosCatalogo;
	}

	public void agregarLibroCatalogo(Libro libro){
		librosCatalogo.add(libro);
		
	}

	public void eliminarLibroCatalogo(Libro libro) {
		librosCatalogo.remove(libro);
		
	}
	
	public LinkedList<Libro> obtenerCatalogo(){
		return librosCatalogo;
	}
	
}
