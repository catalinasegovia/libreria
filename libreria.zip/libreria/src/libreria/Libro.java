package libreria;

public class Libro {
	private int idLibro;
	private String titulo;
	private double precio;
	private String nombreAutor;
	private String  nombreEditorial;
	private String nombreCategoria;
	
	
	public Libro(int idLibro, String titulo, double precio, String nombreAutor, String nombreEditorial,
			String nombreCategoria) {
		super();
		this.idLibro = idLibro;
		this.titulo = titulo;
		this.precio = precio;
		this.nombreAutor = nombreAutor;
		this.nombreEditorial = nombreEditorial;
		this.nombreCategoria = nombreCategoria;
	} 
	
	public int getIdLibro() {
		return idLibro;
	}



	public void setIdLibro(int idLibro) {
		this.idLibro = idLibro;
	}



	public String getTitulo() {
		return titulo;
	}



	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}



	public double getPrecio() {
		return precio;
	}



	public void setPrecio(double precio) {
		this.precio = precio;
	}



	public String getNombreAutor() {
		return nombreAutor;
	}



	public void setNombreAutor(String nombreAutor) {
		this.nombreAutor = nombreAutor;
	}



	public String getNombreEditorial() {
		return nombreEditorial;
	}



	public void setNombreEditorial(String nombreEditorial) {
		this.nombreEditorial = nombreEditorial;
	}



	public String getNombreCategoria() {
		return nombreCategoria;
	}



	public void setNombreCategoria(String nombreCategoria) {
		this.nombreCategoria = nombreCategoria;
	}



	
	

}
