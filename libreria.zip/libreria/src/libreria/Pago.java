package libreria;

public class Pago {
	
	private int idPago; 
	private String metodoDePago;
	private double montoTotal;
	
	public Pago(int idPago, String metodoDePago, double montoTotal) {
		super();
		this.idPago = idPago;
		this.metodoDePago = metodoDePago;
		this.montoTotal = montoTotal;
	}
	
	public int getIdPago() {
		return idPago;
	}


	public void setIdPago(int idPago) {
		this.idPago = idPago;
	}


	public String getMetodoDePago() {
		return metodoDePago;
	}


	public void setMetodoDePago(String metodoDePago) {
		this.metodoDePago = metodoDePago;
	}


	public double getMontoTotal() {
		return montoTotal;
	}


	public void setMontoTotal(double montoTotal) {
		this.montoTotal = montoTotal;
	}


	
	
	
}
