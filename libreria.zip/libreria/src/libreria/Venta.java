package libreria;

import java.time.LocalDate;

public class Venta {

	private int idVenta;
	private LocalDate fechaDeVenta;
	
	
	public Venta(int idVenta, LocalDate fechaDeVenta) {
		super();
		this.idVenta = idVenta;
		this.fechaDeVenta = fechaDeVenta;
	}


	public int getIdVenta() {
		return idVenta;
	}


	public void setIdVenta(int idVenta) {
		this.idVenta = idVenta;
	}


	public LocalDate getFechaDeVenta() {
		return fechaDeVenta;
	}


	public void setFechaDeVenta(LocalDate fechaDeVenta) {
		this.fechaDeVenta = fechaDeVenta;
	}
	
	
	
}
