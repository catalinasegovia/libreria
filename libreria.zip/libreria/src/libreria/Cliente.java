package libreria;

import java.util.LinkedList;

public class Cliente extends Persona {

	
	private int idCliente ;
	private int telefono;
	private String mail;
	private LinkedList<DireccionCliente> direcciones;
	
	
	public Cliente(String nombre, String apellido, int idCliente, int telefono, String mail) {
		super(nombre, apellido);
		this.idCliente = idCliente;
		this.telefono = telefono;
		this.mail = mail;
	}

	public Cliente() {
		
	}

	public int getIdCliente() {
		return idCliente;
	}



	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}



	public int getTelefono() {
		return telefono;
	}



	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}



	public String getMail() {
		return mail;
	}



	public void setMail(String mail) {
		this.mail = mail;
	}


	public void agregarDireccion( DireccionCliente direccion) {
		direcciones.add(direccion);
	}
	
	
	
	
}
