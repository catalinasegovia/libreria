package libreria;

import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) {
		
		
		String [] opciones = {
				"Cliente" , "Bibliotecario", "Salir"
		};
	
		int opcion =0;

	
	do {
		opcion = JOptionPane.showOptionDialog(null, "Seleccione el usuario correspondiente" , null, 0, 0, null,  opciones, opciones[0]);
		
		switch(opcion) {
		case 0:
			JOptionPane.showMessageDialog(null, "Cliente");
			Cliente cliente1 = new Cliente();
			break;
			
		case 1:
			JOptionPane.showMessageDialog(null, "Bibliotecario");
			Bibliotecario biblio1 = new Bibliotecario();
			break;
			
			
		case 2:
			JOptionPane.showMessageDialog(null, "Salir");
			break;
			
			default:
				break;
		}
		
	}while (opcion!=2);
	
	
}
}