package libreria;

import java.time.LocalDate;
import java.util.LinkedList;


public class CarritoDeCompras {
	
	private int idCarrito;
	private String estadoDelLibro;
	private LocalDate fechaDeCreacion;
	private LinkedList <Libro> libros;
	
	
	public CarritoDeCompras(int idCarrito, String estadoDelLibro, LocalDate fechaDeCreacion, LinkedList<Libro> libros) {
		super();
		this.idCarrito = idCarrito;
		this.estadoDelLibro = estadoDelLibro;
		this.fechaDeCreacion = fechaDeCreacion;
		this.libros = libros;
	}

	
	public void agregarLibroCarrito(Libro libro) {
		libros.add(libro);
		System.out.println(libro.getTitulo());
		
	}

	public void eliminarLibroCarrito(Libro libro) {
		
	}

	public double calcularTotal() {
		return 0;
	}
	
	public void relizarCompra() {
		
	}

}
